#include "tinyTLS.h"
#include "tinyTLSClient.h"
#include "tinyTLSServer.h"

#include <bits/stdint-uintn.h>
#include <cstring>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>
#include <string>

TLSClient::TLSClient(unsigned int _studentID) { studentID = _studentID; }


int TLSClient::handshake(TLSServer *server, const char* serverName) {
  int ret = -1;
  struct client_hello *hello = generateClientHello();
  if(hello == nullptr){
    printf("Client: You MUST implent generateClientHello() Function!\n");
    return -1;
  }
  auto serverHello = (struct server_hello *)server->handshake(hello);

  auto keyExchange = generateClientKeyExchange(serverHello->cert, serverName);
  if(keyExchange == nullptr){
    printf("Client: You MUST implent generateClientKeyExchange() Function!\n");
    return -1;
  }
  auto serverKeyExchange =
      (struct server_key_exchange *)server->handshake(keyExchange);

  if (serverKeyExchange == nullptr) {
    printf("Client: Handshake abort\n");
  } else {
    printf("Client:Handshake done! sessionkey:");
    print_hex(sessionKey, SHA256_DIGEST_LENGTH);
    free(serverKeyExchange);
    ret = 0;
  }
  delete serverHello->cert;
  free(hello);
  free(serverHello);
  free(keyExchange->encrypted_PMS);
  free(keyExchange);
  return ret;
}

struct client_hello *TLSClient::generateClientHello() {
  struct client_hello *clientHello = nullptr;

  // -------Write your code on here--------
  
  // --------------------------------------

  return clientHello;
}

struct client_key_exchange *
TLSClient::generateClientKeyExchange(Certificate *cert, const char* servername) {
  struct client_key_exchange *clientKeyExchange = nullptr;

  // -------Write your code on here--------
  /*
  1) Check Certificate's valid.
  2) generate Pre Master Secret
  3) encrypt Pre Master Secret by key on certificate
  4) generate sessionkey base on Pre Master Secret
  */

  // --------------------------------------
  return clientKeyExchange;
}

