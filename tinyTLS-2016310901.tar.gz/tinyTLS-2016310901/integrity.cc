#include "tinyTLS.h"
#include "integrity.h"

int TLS::addTag(uint8_t *msg, uint8_t *out) {
  // Write your code here
  return 0;
}

int TLS::checkTag(uint8_t *tag, ssize_t taglen) {
  // Write your code here - return 0 if tag is valid and return -1 if tag is
  // invalid
  return 0;
}

int check_integrity(){
  TLSServer* server = new TLSServer("sslab.ctf.MIDTERM");
  TLSClient* client = new TLSClient(STUDENT_ID);

  if(client->handshake(server, "sslab.ctf.MIDTERM") == -1){
    return -2;
  }
  uint8_t buffer[2048]="CHECK MSG";
  uint8_t cipherText[2048] = {0};
  int cipherlen = 0;
  int taglen = client->sendData(server, buffer, cipherText, &cipherlen);
  cipherText[cipherlen - 0x4] += 1;
  bzero(buffer, 2048);
  return server->recvData(cipherText, buffer, cipherlen, taglen);
}