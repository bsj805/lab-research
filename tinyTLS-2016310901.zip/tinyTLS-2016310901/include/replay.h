#pragma once
#include <map>
#include <string>

int replay();