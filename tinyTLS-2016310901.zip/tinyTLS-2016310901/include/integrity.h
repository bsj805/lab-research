#pragma once
#include "tinyTLS.h"
#include "tinyTLSServer.h"
#include "tinyTLSClient.h"

#include <cstring>

int check_integrity();