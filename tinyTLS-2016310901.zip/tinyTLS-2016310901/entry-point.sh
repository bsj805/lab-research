#!/bin/bash

runuser -u challenger -- fish
