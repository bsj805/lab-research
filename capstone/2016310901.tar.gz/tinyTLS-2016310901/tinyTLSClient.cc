#include "tinyTLS.h"
#include "tinyTLSClient.h"
#include "tinyTLSServer.h"

#include <bits/stdint-uintn.h>
#include <cstring>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>
#include <openssl/err.h>
#include <openssl/bio.h>
#include <string>
uint8_t * newPMS;
TLSClient::TLSClient(unsigned int _studentID) { studentID = _studentID; }


int TLSClient::handshake(TLSServer *server, const char* serverName) {
  int ret = -1;
  struct client_hello *hello = generateClientHello();
  if(hello == nullptr){
    printf("Client: You MUST implent generateClientHello() Function!\n");
    return -1;
  }
  auto serverHello = (struct server_hello *)server->handshake(hello);

//generateClientHello()에서 (uint64_t *)hello[0]==MAGIC_CLIENT_HELLO 가 나오게 했다면 즉, 첫항목이 MAGIC_CLIENT_HELLO인경우  send_server_hello()가 serverHello에저장
//send_server_hello는 hello->magic=MAGIC_SERVER_HELLO로 만들고, hello->cert=cert 즉 서버의 cert로 만들어반환해준다.
//즉 serverHello->magic이랑 serverHello->cert를 쓸수있다!

  auto keyExchange = generateClientKeyExchange(serverHello->cert, serverName);
  if(keyExchange == nullptr){
    printf("Client: You MUST implent generateClientKeyExchange() Function!\n");
    return -1;
  }
  auto serverKeyExchange =
      (struct server_key_exchange *)server->handshake(keyExchange);

  if (serverKeyExchange == nullptr) {
    printf("Client: Handshake abort\n");
  } else {
    printf("Client:Handshake done! sessionkey:");
    print_hex(sessionKey, SHA256_DIGEST_LENGTH);
    //free(serverKeyExchange);
    ret = 0;
  }
  //delete (serverHello->cert);
  //free(hello);
  //free(serverHello);
  //free(keyExchange->encrypted_PMS);
//free(newPMS);
  //free(keyExchange);
  return ret;
}

struct client_hello *TLSClient::generateClientHello() {
  struct client_hello *clientHello = nullptr;
	clientHello=(struct client_hello*)malloc(sizeof(struct client_hello));
	//magic을 MAGIC_CLIENT_HELLO로바꿔줘야// 헐.. CILENT였어;;
	clientHello->magic=MAGIC_CILENT_HELLO;
	
	/*
struct client_hello {
  uint64_t magic;
  unsigned int student_id;}; //이건 authentification용이겠지?
struct server_hello {
  uint64_t magic;
  Certificate *cert;
};
*/

  // -------Write your code on here--------
  
  // --------------------------------------

  return clientHello;
}

struct client_key_exchange *
TLSClient::generateClientKeyExchange(Certificate *cert, const char* servername) {
  struct client_key_exchange *clientKeyExchange = nullptr;
	clientKeyExchange=(struct client_key_exchange*)malloc(sizeof(struct client_key_exchange));
	clientKeyExchange->magic=MAGIC_CLIENT_KEY_EXCHANGE;

 int err=cert->checkValid(servername);
	if(err!=0)
{	
//	printf("error in cert->checkValid %d\n",err);
//	printf("IDNONWANTGO");
	clientKeyExchange->errorno=8;
	return clientKeyExchange;
}
/*
 struct client_key_exchange {
uint64_t magic;
uint8_t *encrypted_PMS;
ssize_t pms_len;
uint8_t errorno;
};
*/

	  // -------Write your code on here--------
  /*
  1) Check Certificate's valid.
  2) generate Pre Master Secret
  3) encrypt Pre Master Secret by key on certificate
  4) generate sessionkey base on Pre Master Secret
  */
	//먼저 1번문제
//먼저 cert->signed Hash를 rsa_priv_decrypt로 rootca를이용해 복호화한다.
//그럼 cert->hash값이 나오는데, 우리도 같은 rootCA써서 sha256 3번 한거 생성하고 이거랑 strcmp해서 0나오면 둘이같은거
//printf("checkvalid\n");


	RSA *rootsCA=NULL;
	RSA *serverskey=NULL;
//	cert->serverPubkeyPEM 이걸로 sha256 해싱할꺼야. 이게 serverkey
//cert->signingkeyPEM 이게 rootCA;
// char* to RSA*
	//BIO *pub=BIO_new(BIO_s_mem());
	//cert->serverPubkeyPEM[247]='\0';
	//cert->signingkeyPEM[247]='\0';
	BIO *pub=BIO_new(BIO_s_mem());
	ssize_t keylen=strlen(cert->serverPubkeyPEM);
	
	//BIO *pub=BIO_new_mem_buf(cert->serverPubkeyPEM,-1);

	//printf("######signingkeyPEM\n\n\n%s\n\n\n######\n",cert->signingkeyPEM);
	//printf("######signingkeyPEM\n\n\n%s\n\n\n######\n",cert->serverPubkeyPEM);
	BIO_write(pub,cert->serverPubkeyPEM,(int)keylen);
	PEM_read_bio_RSAPublicKey(pub,&serverskey,NULL,NULL);
	
	BIO_free(pub);

	pub=BIO_new(BIO_s_mem());
	//BIO *pub2=BIO_new_mem_buf(cert->signingkeyPEM,-1);
	BIO_write(pub,cert->signingkeyPEM,(int)strlen(cert->signingkeyPEM));
	PEM_read_bio_RSAPublicKey(pub,&rootsCA,NULL,NULL);
	BIO_free(pub);
	
	uint8_t *decry=(uint8_t *)malloc(RSA_size(rootsCA));
	int ourlen=128;
	//printf("#%disRSASIZE#####%dsignedHash\n\n\n%s\n\n\n######\n",RSA_size(rootsCA),err,cert->signedHash);
	
	//printf("######hash\n\n\n%s\n\n\n######\n",cert->signedHash);
	//printf("######hash\n\n\n%s\n\n\n######\n",cert->hash);
	err=RSA_public_decrypt(RSA_size(rootsCA),cert->signedHash,decry,rootsCA,RSA_PKCS1_PADDING);//상대가 priv encr했으니 난 pub decr
	/*for(int d=0;d<(int)strlen((char*)(cert->signedHash));d++)
	{
		printf("[%d]=%d ", d,cert->signedHash[d]);
	}*/
	if(err==-1)
{
	err = ERR_get_error(); //padding이 invalid하대
    char buf[4096] = {0};
    ERR_error_string(err, buf);
  //  printf("error:%s\n", buf);
}

	int j,wrong;
	wrong=0;
	//decry[err]='\0';// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//cert->hash[err]='\0';//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	//printf("decry%s\n",decry);
	//printf("%s\n",cert->hash);
	/*
	if(!strcmp((char*)decry,((char*)cert)->hash))
	{
		wrong=-1;
		printf("wrong!!");
	}*/
	j=0;
	while(decry[j]!='\0')
	{
		if(decry[j] !=cert->hash[j])
		{
			wrong=-1;
//			printf("wron%d\n",j);
		}
		j++;
	}
//	printf("clear"); we first checked whether rootsCA is valid and is decryptable and is same with cert->hash
// and then, we compare cert->hash with our making value as below
	if(wrong==-1){clientKeyExchange->errorno=8;}
	uint8_t tbuffer[3][SHA256_DIGEST_LENGTH];//32
	//free(decry);
uint8_t ourhash[SHA256_DIGEST_LENGTH];
	SHA256_CTX c;
	SHA256_Init(&c);
	SHA256_Update(&c, cert->CN,strlen(cert->CN));
	SHA256_Final(tbuffer[0],&c);
		SHA256_Init(&c);
	SHA256_Update(&c, &cert->expire_date,sizeof(uint64_t));
	SHA256_Final(tbuffer[1],&c);
	SHA256_Init(&c);
	SHA256_Update(&c, cert->serverPubkeyPEM,strlen(cert->serverPubkeyPEM));
	SHA256_Final(tbuffer[2],&c);
/*
printf("@@@@\n");
printf("0%s\n",tbuffer[0]);
printf("1%s\n",tbuffer[1]);
printf("2%s\n",tbuffer[2]);
printf("@@@@\n");*/

  SHA256_Init(&c);
  SHA256_Update(&c, tbuffer[0], SHA256_DIGEST_LENGTH);
  SHA256_Update(&c, tbuffer[1], SHA256_DIGEST_LENGTH);
  SHA256_Update(&c, tbuffer[2], SHA256_DIGEST_LENGTH);
  SHA256_Final(ourhash, &c);
 //printf("@@@%s@@@\n",ourhash);
//we make same hash value as the server does 
 //Since the hash file using the content of cert struct and hashed value of cert->hash is same, it is valid
int p;
wrong=0;
for(p=0;p<SHA256_DIGEST_LENGTH;p++)
{
	if(ourhash[p]!=cert->hash[p])
	{
	//printf("!!!%d != %d !!%d!\n",ourhash[p],cert->hash[p],p);
	wrong=-1;
	break;
	}
}
if(wrong==-1)
{
clientKeyExchange->errorno=8;
}
else
{
	//printf("validation tested\n");
}
//Now, we tested the validation of the sent message! 

	//PEM_read_bio_RSAPublicKey(pub,
	//RSA_private_decrypt(RSA_size(
	//2번문제

	auto PMS=(uint8_t *)malloc(48);
	//clientKeyExchange->encrypted_PMS=PMS;
	//PMS는 encrypt with server key 해야해. 48byte
	srand((unsigned)time(NULL));
	//printf("PMSSSSSSSSSSSSSSSSS\n");
	for(j=0;j<48;j++)
	{
		PMS[j]=rand()%256;
		//printf("%d ",PMS[j]);
	}
	//printf("random%d",PMS[5]);
	//printf("\n\n\n\n\n\n");
	int num;

	newPMS=(uint8_t *)malloc(48);
	//newPMS=(uint8_t *)malloc(48);
	clientKeyExchange->encrypted_PMS=newPMS;
//subtask3여기

	//uint8_t sessKEY[1024]; //SESSIONKEY만들기
	num=RSA_public_encrypt(48,PMS,clientKeyExchange->encrypted_PMS,serverskey,RSA_PKCS1_OAEP_PADDING);
//	  SHA256_CTX c; subtask 4 시작
	 SHA256_Init(&c);

   newPMS[num]='\0';
	 SHA256_Update(&c, PMS, 48);//PMS를 sha256으로 해시해버려 그럼 sessionkey가나온대.
	SHA256_Final(sessionKey, &c);
	//printf("we made seesionbkey\n");
	//print_hex(sessKEY,SHA256_DIGEST_LENGTH);//출력해서비교해보자
	//printf("wright?");
	if (num == -1) {
    //printf("error:\n" );
  }

	//free(PMS);
  // --------------------------------------
  return clientKeyExchange;
}

