#include "certificate.h"
#include "tinyTLS.h"

#include <cstring>

int Certificate::checkValid(const char *domain) {
  int errorno = 0;
  if (expire_date < (unsigned)time(NULL)) {
    errorno |= CERTERR_EXPIRE;
  }
  if (!strcmp(signingkeyPEM, serverPubkeyPEM)) { //같으면 0. 즉 같을때에 실행)
    errorno |= CERTERR_SELFSIGN; //그래서 같을때는 selfsignin
  }
  if (strcmp(CN, domain)) { //다를때에 실행
    errorno |= CERTERR_WRONGCN;
	//printf("name=%s\n\n",CN);
  }
  return errorno;
}

Certificate::Certificate(const char *name) {
  if (strlen(name) > 32) {
    return;
  }
  memcpy(CN, name, strlen(name));//CN에 name을 복사
}
Certificate::~Certificate() {
  if(signedHash!=nullptr)
{  //free(signedHash);
}
 if(serverPubkeyPEM!=nullptr)
  free(serverPubkeyPEM);
 if(signingkeyPEM!=nullptr)
  free(signingkeyPEM);
}
