#include "tinyTLSServer.h"
#include "tinyTLS.h"

#include <bits/stdint-uintn.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>
#include <string.h>
#include <string>

TLSServer::TLSServer(const char *serverName) { //첫생성이네
  rootCA = gernerateRSA();
  serverkey = gernerateRSA();
  int len = strlen(serverName);
  memcpy(CN, serverName, len > 32 ? 32 : len); //server이름이 CN에들어가있어
  CN[len] = 0;
  cert = generateCert(serverkey, rootCA);//자신의 certificate을 만든다.
}

TLSServer::TLSServer(const char *serverName, RSA *_serverkey, RSA *_rootCA) {
  rootCA = _rootCA;
  serverkey = _serverkey;
  cert = generateCert(serverkey, rootCA);
  int len = strlen(serverName);
  memcpy(CN, serverName, len > 32 ? 32 : len);
}

struct server_hello *TLSServer::send_server_hello() {
  auto hello = (struct server_hello *)malloc(sizeof(struct server_hello));
  hello->magic = MAGIC_SERVER_HELLO;
  hello->cert = cert;
  return hello;
}

struct server_hello *TLSServer::send_server_hello(int n) {
  auto hello = (struct server_hello *)malloc(sizeof(struct server_hello));
  hello->magic = MAGIC_SERVER_HELLO;
  if (n == 0)
    hello->cert = nullptr;
  else
    hello->cert = generateCert(serverkey, rootCA);
  return hello;
}

struct server_key_exchange *
TLSServer::send_server_key_exchange(struct client_key_exchange *param) {
  if (param->errorno != 0) {
    printf("%s Server: Client abort due to worng certificate: %d\n", CN,
           param->errorno);
    return nullptr;
  }
  auto PMS = (uint8_t *)malloc(48); //pre-master key 이게 shared secret client에서만든거.
  RSA_private_decrypt(RSA_size(serverkey), param->encrypted_PMS, PMS, serverkey,
                      RSA_PKCS1_OAEP_PADDING);  //param->encrypted_PMS 에서 PMS로 RSA decrypt
  SHA256_CTX c;
  SHA256_Init(&c);
  SHA256_Update(&c, PMS, 48);//PMS를 sha256으로 해시해버려 그럼 sessionkey가나온대.
  /*for(int d=0;d<48;d++)
{
	printf("%d ",PMS[d]);
}*/
  SHA256_Final(sessionKey, &c);
  printf("%s Server:handshake Done! sessionKey:", CN);
  print_hex(sessionKey, SHA256_DIGEST_LENGTH);//32만큼표시해라
  auto ret =
      (struct server_key_exchange *)malloc(sizeof(struct server_key_exchange));
  ret->magic = MAGIC_SERVER_KEY_EXCHANGE; //
 // free(PMS);
  return ret;
}

void *TLSServer::handshake(void *param) {
  if (((uint64_t *)param)[0] == MAGIC_CILENT_HELLO) {
    return (void *)send_server_hello();
  } else if (((uint64_t *)param)[0] == MAGIC_CLIENT_KEY_EXCHANGE) {
    return (void *)send_server_key_exchange(
        (struct client_key_exchange *)param);
  } else {
    return nullptr;
  }
}

Certificate *TLSServer::generateCert(RSA *_serverkey, RSA *_rootCA) {
  uint8_t buffer[3][SHA256_DIGEST_LENGTH];//32
  Certificate *cert = new Certificate(CN);
  cert->expire_date = 1650294000; // 2022-04-19 00:00:00
  SHA256_CTX c;
  SHA256_Init(&c);
  SHA256_Update(&c, cert->CN, strlen(cert->CN));
  SHA256_Final(buffer[0], &c); 

  SHA256_Init(&c);
  SHA256_Update(&c, &cert->expire_date, sizeof(uint64_t));
  SHA256_Final(buffer[1], &c);
  BIO *bio = BIO_new(BIO_s_mem());
  PEM_write_bio_RSAPublicKey(bio, _serverkey); //openssl pem형식의 public key를 추출한다.

  ssize_t keylen = BIO_pending(bio);
  //printf("keylenofserver=%d\n",keylen);
  cert->serverPubkeyPEM = (char *)malloc(keylen + 1);
  bzero(cert->serverPubkeyPEM, keylen + 1);
  BIO_read(bio, cert->serverPubkeyPEM, keylen);//openssl, cert->serverPubkeyPEM이라는 버퍼에 keylen만큼을 옮긴다.
//bio에서 keylen byte만큼을 옮긴다.
  SHA256_Init(&c);
  SHA256_Update(&c, cert->serverPubkeyPEM, keylen);//sha256
  SHA256_Final(buffer[2], &c);
/*	printf("@@@@\n");
printf("0%s\n",buffer[0]);
printf("1%s\n",buffer[1]);
printf("2%s\n",buffer[2]);
printf("@@@@\n");*/

  BIO_free(bio);

//	uint8_t *frd;
  SHA256_Init(&c);
  SHA256_Update(&c, buffer[0], SHA256_DIGEST_LENGTH);
  SHA256_Update(&c, buffer[1], SHA256_DIGEST_LENGTH);
  SHA256_Update(&c, buffer[2], SHA256_DIGEST_LENGTH);
  SHA256_Final(cert->hash, &c);
//printf("@@@%s@@@\n",cert->hash);

  bio = BIO_new(BIO_s_mem());

  PEM_write_bio_RSAPublicKey(bio, _rootCA);//rootCA추출
  keylen = BIO_pending(bio);
  cert->signingkeyPEM = (char *)malloc(keylen + 1);//rootCA가 담겨있다.
 // printf("key%dlenofrootca=%d\n",RSA_size(_rootCA),keylen);
  bzero(cert->signingkeyPEM, keylen + 1);
  BIO_read(bio, cert->signingkeyPEM, keylen);//cert->signingkeyPEM이란 버퍼에 추출한 pubkey옮기기
  BIO_free(bio);
/////////////////////////////////////////////////////////////
/*
	cert->signingkeyPEM[247]='\0';
	printf("######signingkeyPEM\n\n\n%s\n\n\n######\n",cert->signingkeyPEM);
	BIO *nebo=BIO_new(BIO_s_mem());
	RSA *atd=NULL;
	BIO_write(nebo,cert->signingkeyPEM,(int)strlen(cert->signingkeyPEM));
	
if(!PEM_read_bio_RSAPublicKey(bio,&changed,NULL,NULL))
{
printf("eerrrrorr\n");
}
	PEM_read_bio_RSAPublicKey(nebo,&atd,NULL,NULL);
	frd=(uint8_t *)malloc(RSA_size(_rootCA));
	int werr=RSA_private_encrypt(SHA256_DIGEST_LENGTH,cert->hash, _rootCA, atd,RSA_PKCS1_PADDING);
	printf("%dfriend\n\n",werr);
	for(int p=0;p<32;p++)
	{
		printf("%d ",frd[p]);
	}
	printf("fri%dend\n\n",RSA_size(atd));

	BIO_free(nebo);*/
////////////////////////////////////////////////////////////////////////
  cert->signedHash = (uint8_t *)malloc(RSA_size(_rootCA));
//uint8_t decry[1024];
  int err = RSA_private_encrypt(SHA256_DIGEST_LENGTH, cert->hash,
                                cert->signedHash, _rootCA, RSA_PKCS1_PADDING);//cert->hash라는 평문을 _rootCA라는 RSAkey로 32
																		//SHA256_DIGEST_LENGTH(32)만큼 암호화를 수행해, cert->signedHash라는 암호문을 생성한다. RSA_private_decrypte경우 해당 rsa key로 복호화 할 수 있다. from, to 위치 그대로.
//	printf("howmuc%dh",err);
//	err=RSA_public_decrypt(err,cert->signedHash,decry,_rootCA,RSA_PKCS1_PADDING);
//	printf("decry:%s###\n",decry);
  if (err == -1) {
    err = ERR_get_error();
    char buf[4096] = {0};
    ERR_error_string(err, buf);
    printf("error:%s\n", buf);
    return nullptr;
  }
  return cert;
}

RSA *TLSServer::CAkeyLeak() { return rootCA; }
