#include "tinyTLS.h"
#include "integrity.h"
#include <bits/stdint-uintn.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>
#include <string.h>
#include <string>



//uint8_t ciphed[SHA256_DIGEST_LENGTH];
int TLS::addTag(uint8_t *msg, uint8_t *out) {//tls checks integrity using mac, which uses message as input. 
  // Write your code here
//out의 [0]부터 써넣으면된다.
//we use mac to ensure integrity of tls communication
//I'll take session key as to make sure integrity of msg
//and sha-256 to hash msg into small value

  SHA256_CTX c;
  SHA256_Init(&c);
  int num;
  num=(int)strlen((const char*)msg);
  uint8_t tagarr[1024];
//unsigned char hash[SHA256_DIGEST_LENGTH+1];
/*for(int q=0;q<num;q++)
{
	printf("[%d]=%d ",q,msg[q]);
}*/

memcpy(tagarr,msg,num);
tagarr[num]='\0';
//printf("@@@%s@@@",(char*)tagarr);
  SHA256_Update(&c,tagarr,num);
  uint8_t ciphed[SHA256_DIGEST_LENGTH+1];
for(int q=0;q<SHA256_DIGEST_LENGTH+1;q++)ciphed[q]=0;
  SHA256_Final(ciphed,&c);
ciphed[num]='\0';

//printf("@@@%s@@@%d",(char*)ciphed,num);

  num=(int)strlen((const char*)ciphed)+1;
  ciphed[SHA256_DIGEST_LENGTH]=(int)strlen((const char*)msg);
memcpy(out,ciphed,num);
  
out[num-1]=ciphed[SHA256_DIGEST_LENGTH];
//printf("done");
  
  return num;
}

int TLS::checkTag(uint8_t *tag, ssize_t taglen) {
  // Write your code here - return 0 if tag is valid and return -1 if tag is
  // invalid
   uint8_t tagarr[1024];//to store taglen, tag's largest value is 256 bit
	
   int q;int num;
  num=tag[taglen-1]; //ciphertext의 길이가 들어있다.
	uint8_t *arr=tag;
	arr-=num; //we can get ciphertext address
/*for(q=0;q<num;q++)
{
	printf("[%d]=%d ",q,arr[q]);
}*/
	memcpy(tagarr,arr,num);
tagarr[num]='\0';
//printf("@@@%s@@@",(char*)tagarr);
	SHA256_CTX c;
   SHA256_Init(&c);
//printf("%d==nummmmmmmmmmmmmmmm\n",num);
  SHA256_Update(&c,tagarr,num);
  uint8_t ciphed[SHA256_DIGEST_LENGTH+1];
	for(q=0;q<SHA256_DIGEST_LENGTH+1;q++)ciphed[q]=0;
  SHA256_Final(ciphed,&c); //SHA256값을 얻는다. cipher text로 hash한
ciphed[num]='\0';

//printf("@@@%s@@@%d",(char*)ciphed,num);
num=(int)strlen((const char*)ciphed)+1;

  for(q=0;q<num;q++)//원랜 마지막바이트를 cipherlength로 해주었다.
  {
	if(tag[q]!=ciphed[q])
	{
		return -1;
	} //자꾸 틀리네
//ㅇㅇ.. 틀릴수밖에 왜냐하면 여기 자체가 맞는 전송이 아니야..
//틀려야 정답이었어.
//		printf("so[%d]<- tag mething[%d]wrong\n",tag[q],ciphed[q]);
}
  return 0;
}

int check_integrity(){
  TLSServer* server = new TLSServer("sslab.ctf.MIDTERM");
  TLSClient* client = new TLSClient(STUDENT_ID);

  if(client->handshake(server, "sslab.ctf.MIDTERM") == -1){
    return -2;
  }
  uint8_t buffer[2048]="CHECK MSG";
  uint8_t cipherText[2048] = {0};
  int cipherlen = 0;
  int taglen = client->sendData(server, buffer, cipherText, &cipherlen);
  cipherText[cipherlen - 0x4] += 1;
  bzero(buffer, 2048);
  return server->recvData(cipherText, buffer, cipherlen, taglen);
}
