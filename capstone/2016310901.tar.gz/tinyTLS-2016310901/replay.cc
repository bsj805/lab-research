#include "replay.h"
#include "tinyTLS.h"
#include "tinyTLSClient.h"
#include "tinyTLSServer.h"
#include <cstring>
#include <iostream>

int replay() {
  uint8_t ctbuffer[2048] = {0};
  uint8_t ptbuffer[2048] = {0};
  TLSServer *bank = new TLSServer("sslab.ctf.MIDTERM");
  TLSClient *victim = new TLSClient(STUDENT_ID);
  if(victim->handshake(bank, "sslab.ctf.MIDTERM") == -1){
    std::cout << "Handshake not done!\n";
    return 0;
  };
  int cryptlen = 0;
  int taglen = victim->sendData(bank, (uint8_t *)"ALICE SEND 10000 TO EVE", ctbuffer,
                                &cryptlen);

  // This is relpay attack!
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen);
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen);
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen);
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen);
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen);
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen);
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen);

  // Protect this protocol from replay attack!
  taglen =
      victim->sendData(bank, (uint8_t *)"ALICE SEND 10000 TO EVE", ctbuffer, &cryptlen, 0);
  bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen, 0);
  return bank->recvData(ctbuffer, ptbuffer, cryptlen, taglen, 0);
}

int TLS::recvData(uint8_t *cipherText, uint8_t *out, ssize_t cryptolen,
                  ssize_t taglen, int replay) {
  // Write your code here
}

int TLS::sendData(TLS* other, uint8_t *data, uint8_t *out, int *outl, int replay) {
  // Write your code here
}