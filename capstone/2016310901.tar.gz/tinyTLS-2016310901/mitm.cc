#include "certificate.h"
#include "tinyTLS.h"
#include "tinyTLSClient.h"
#include "tinyTLSServer.h"

#include <bits/stdint-uintn.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>
#include <string.h>
#include <string>

int mitm() {
  // Attacker make success that victim is access on their own server. But
  // unfortunantly, connection use TLS So victim abort access because of
  // authentication. Make sure that MITM(Man In The Middle) attack success!
  TLSServer *victimServer = new TLSServer("sslab.ctf.MIDTERM");//cert만들어진다.
  TLSClient *victimClient = new TLSClient(STUDENT_ID);
  TLSServer *fakeServer = new TLSServer("FAKESERVER");//cert만들어짐
  TLSClient *fakeClient = new TLSClient(STUDENT_ID);

  RSA* leakKey = victimServer->CAkeyLeak();
  // Write your code on here
  // Hint) Authentication is based on certificate.
	//rootCA를 아는상태이다. setCertificate 함수를 이용하자 이걸 설정해주면 진짜서버인척할수있다.
//또한 TLSServer("서버이름,RSA *serverkey, RSA * rootCA) 이 생성자를 이용하면 원하는 CERT를만들수있다.
//그럼 server key를 얻어오거나, certificate을 얻어야한다. 
  struct client_hello *hello=fakeClient->generateClientHello();
  auto serverHello= (struct server_hello *)victimServer->handshake(hello);
  //now we get serverHello->cert
  //fakeServer->setCertificate(serverHello->cert);root_CA만 victim서버거를 쓰고, public,privkey 서버키는 자기꺼
  //어차피 서버가 내가원하는서버인지는 cert->CN,cert->expire_date,cert->hash,cert->signingkeyPEM. 즉,
//serverkey는 authentification에 필요없다. 
  auto serverHello2= (struct server_hello *)fakeServer->handshake(hello);//fakeserver의 cert얻기
  /*int len=strlen("sslab.ctf.MIDTERM");
  int i,j;
 
  memcpy(serverHello2->cert->CN,"sslab.ctf.MIDTERM",len);
  memcpy(serverHello2->cert->signingkeyPEM,serverHello->cert->signingkeyPEM,strlen(serverHello->cert->CN));
  memcpy(serverHello2->cert->hash,serverHello->cert->hash,strlen((char*)serverHello->cert->hash));
  memcpy(serverHello2->cert->signedHash,serverHello->cert->signedHash,strlen((char*)serverHello->cert->signedHash));
  
  printf("rootca:%s@@@",serverHello2->cert->signingkeyPEM);
    printf("sginedHash:%s@@@",serverHello2->cert->signedHash);
 printf("hash:%s@@@",serverHello2->cert->hash);
 //printf("rootca:%s@@@",serverHello2->cert->signingkeyPEM);
 
  serverHello2->cert->expire_date=serverHello->cert->expire_date;
  //server public key빼고 모두바꾼것. 이렇게 하지 않고 그냥 cert를 옮겨버린다면 상관은없겠다. 어차피 serverkey 알아서 갖고있으니. 
 */ 
  char* pubk=(char *)malloc(247);
  char* prevk=(char *)malloc(247);
//  memcpy(pubk,serverHello2->cert->serverPubkeyPEM,strlen(serverHello2->cert->serverPubkeyPEM));
 //memcpy(serverHello->cert->serverPubkeyPEM,pubk,strlen(pubk));
  //serverHello->cert->serverPubkeyPEM=serverHello2->cert->serverPubkeyPEM;
 // memcpy(serverHello->cert->serverPubkeyPEM,serverHello2->cert->serverPubkeyPEM,(int)strlen((char*)serverHello2->cert->serverPubkeyPEM));
  //printf("%dislength",(int)strlen((char*)serverHello2->cert->serverPubkeyPEM));
  //pubk[247]='\0';

  //printf("sigsdsdnsdedhash=%s=======\n",(char*)serverHello2->cert->signedHash);
  char* temprc=(char *)malloc(128);
  memset(temprc,0,128);

  memcpy(temprc,serverHello2->cert->signingkeyPEM,128);
 // memcpy(serverHello2->cert->signingkeyPEM
  uint8_t * temp=(uint8_t*)malloc(RSA_size(leakKey));
  memset(temp,0,RSA_size(leakKey));
  memcpy(temp,serverHello->cert->signedHash,RSA_size(leakKey));//아직대체안됨
  memset(pubk,0,247);
  memset(prevk,0,247);
  memcpy(pubk,serverHello2->cert->serverPubkeyPEM,247);
  memcpy(prevk,serverHello->cert->serverPubkeyPEM,247);
  //printf("@@%s@@\n@@%s@@\n@@%s\n",serverHello->cert->serverPubkeyPEM,serverHello2->cert->serverPubkeyPEM,pubk);
  serverHello->cert->serverPubkeyPEM=pubk;
  serverHello2->cert->serverPubkeyPEM=prevk;//serverkey옮겨두고
  uint8_t tbuffer[3][SHA256_DIGEST_LENGTH];
  uint8_t ourhash[SHA256_DIGEST_LENGTH];


  memcpy(serverHello2->cert->hash,serverHello->cert->hash,SHA256_DIGEST_LENGTH);//hash값미리옮겨두고
 SHA256_CTX c;
  SHA256_Init(&c);
  SHA256_Update(&c, serverHello->cert->CN,strlen(serverHello->cert->CN));
    SHA256_Final(tbuffer[0],&c);
    SHA256_Init(&c);
    SHA256_Update(&c, &serverHello->cert->expire_date,sizeof(uint64_t));
    SHA256_Final(tbuffer[1],&c);
    SHA256_Init(&c);
    SHA256_Update(&c, serverHello->cert->serverPubkeyPEM,strlen(serverHello->cert->serverPubkeyPEM));
    SHA256_Final(tbuffer[2],&c);
  SHA256_Init(&c);
  SHA256_Update(&c, tbuffer[0], SHA256_DIGEST_LENGTH);
  SHA256_Update(&c, tbuffer[1], SHA256_DIGEST_LENGTH);
  SHA256_Update(&c, tbuffer[2], SHA256_DIGEST_LENGTH);
  SHA256_Final(serverHello->cert->hash, &c);
 // serverHello->cert->signedHash=ourhash;
  //BIO *bio=BIO_new(BIO_s_mem());
 // PEM_write_bio_RSAPublicKey(bio,leakkey); //signed hash만드는 과정 반복하기 서버처럼
 // printf("sigsdsdnsdedhash=%s=======\n",(char*)temp);
  memcpy(serverHello2->cert->CN,serverHello->cert->CN,strlen(serverHello->cert->CN));//공유
  serverHello2->cert->expire_date=serverHello->cert->expire_date;//공유
 // free(serverHello2->cert->signedHash);
  serverHello2->cert->signedHash=temp;  
 // free(serverHello->cert->signedHash);
  serverHello->cert->signedHash=(uint8_t *)malloc(RSA_size(leakKey));
memset(serverHello->cert->signedHash,0,RSA_size(leakKey));

  serverHello2->cert->signingkeyPEM=temprc;
  int err = RSA_private_encrypt(SHA256_DIGEST_LENGTH,serverHello->cert->hash,
                                serverHello->cert->signedHash,leakKey, RSA_PKCS1_PADDING);//cert->hash라는 평문을 _rootCA라는 RSAkey로 32
                                                                        //SHA256_DIGEST_LENGTH(32)만큼 암호화를 수행해, cert->signedHash라는 암호문을 생성한다. RSA_private_decrypte경우 해당 rsa key로 복호화 할 수 있다. from, to 위치 그대로.
 //printf("signe%sdhash\n",serverHello->cert->signedHash);
    if (err == -1) {
    err = ERR_get_error();
    char buf[4096] = {0};
    ERR_error_string(err, buf);
    printf("error:%s\n", buf);
	}
  fakeServer->setCertificate(serverHello->cert);
  victimServer->setCertificate(serverHello2->cert);
  //이렇게 serverkey를 전달해주면 되야하는데 
 // auto keyExchange=generateClientKeyExchange(serverHello->cert,"sslab.ctf.MIDTERM");
	//그리고 이제는 기존의 pointer를 모두 가져가버렸으니까 (memcpy로 옮겨준게 아니기때문에)
  
  //
  //
  //
  int res = victimClient->handshake(fakeServer, "sslab.ctf.MIDTERM");
 // printf("HI\n\n\n%s",serverHello->cert->CN);
  res += fakeClient->handshake(victimServer, "sslab.ctf.MIDTERM");//client는 CN을 바꿔주어야한다.
  return res;//returns 0
}
